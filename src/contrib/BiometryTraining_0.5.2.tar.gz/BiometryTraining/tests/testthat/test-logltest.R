load("../dat.asr.Rdata")

test_that("function works", {
  expect_equal(2 * 2, 4)
})
