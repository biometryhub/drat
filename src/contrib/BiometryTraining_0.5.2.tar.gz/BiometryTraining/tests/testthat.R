library(testthat)
library(BiometryTraining)

test_check("BiometryTraining")
