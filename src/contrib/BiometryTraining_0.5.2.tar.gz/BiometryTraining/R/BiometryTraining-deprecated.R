## BiometryTraining-deprecated.r
#' @title Deprecated functions in package \pkg{BiometryTraining}.
#' @description The functions listed below are deprecated and will be removed in
#'   the future. When possible, alternative functions with similar
#'   functionality are also mentioned. Help pages for deprecated functions are
#'   available at `help("<function>-deprecated")`.
#' @name BiometryTraining-deprecated
#' @keywords internal
NULL
